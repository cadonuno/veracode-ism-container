Copyright (c) 2019 Veracode, Inc.

Veracode Internal Scanning Management (ISM) is a simplified approach to web application
scanning for applications hosted within a corporate firewall that cannot 
be reached from the public internet. It allows Veracode to bring uniformity to 
the scanning of external and internal applications for Dynamic Analysis users.

To use ISM to scan your internal applications, you must use 
veracode_ism_install.sh to install the endpoint on your local server.


Instructions: 

- Move the endpoint installer to a machine that is behind your firewall and has access to 
the applications you want Veracode to scan. You must run the endpoint on Linux. If the 
machine requires a different platform, visit the Veracode Help Center and download the 
correct version of the installer.
- To find the endpoint key, go to your gateway page on the Veracode Platform, open the 
Actions menu for this endpoint, and select Copy Endpoint Key.


https://help.veracode.com/