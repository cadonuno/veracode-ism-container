#!/bin/sh
# Copyright (c) 2019 Veracode, Inc.

### BEGIN INIT INFO
# Provides:          Veracode_ISM
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Veracode_ISM
# Description:       Veracode_ISM
### END INIT INFO

JAR_NAME=endpoint.jar
PROCESS_NAME="veracode-ism"
PATH_TO_JAR=$ISM_PRODUCT_HOME$
JAVAEXEC=$JAVA_PATH$
JVMOPTIONS="$JVM_OPTIONS$"


cd $PATH_TO_JAR
case $1 in
    start)
        if [ ! -f ism_pid ]; then
            nohup bash -c "exec -a $PROCESS_NAME $JAVAEXEC -jar $JAR_NAME" 2>> /dev/null >> /dev/null  &
            echo $! > ism_pid
            echo "Endpoint started"
            exit "0"
        else
            PID=$(cat ism_pid);
            if [ -e /proc/$PID ]; then
                echo "Endpoint is already running"
                exit "0"
            else
            nohup bash -c "exec -a $PROCESS_NAME $JAVAEXEC -jar $JAR_NAME" 2>> /dev/null >> /dev/null  &
                echo $! > ism_pid
                echo "Endpoint started"
                exit "0"
            fi
        fi
    ;;
    stop)
        if [ -f ism_pid ]; then
            PID=$(cat ism_pid);
            kill $PID;
            rm ism_pid;
            echo "Endpoint stopped"
            exit "0"
        else
            echo "Endpoint is not running"
            exit "0"
        fi
    ;;
    status)
        if [ -f ism_pid ]; then
            echo "running"
            exit "0"
        else
            echo "stopped"
            exit "0"
        fi
    ;;

esac
