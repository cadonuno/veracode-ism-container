#!/bin/bash
# Copyright (c) 2019 Veracode, Inc.

mode=$1
if [[ -n "$JAVA_HOME" ]] && [[ -x "$JAVA_HOME/bin/java" ]];  then
    echo Using java executable defined in JAVA_HOME $JAVA_HOME
    javaExec="$JAVA_HOME/bin/java"
fi
if [[ -z "$javaExec" ]]; then
    javaExec=`which java`;
fi
if [[ -z "$javaExec" ]]; then
   echo Java not found
   exit
fi
jver=$("$javaExec" -version 2>&1 | awk -F '"' '/version/ {print $2}')
if [[ "$jver" < "1.8" ]]; then
   majorVer=`echo $jver | cut -d'.' -f 1`
   if [[ "$majorVer" -lt 10 ]]; then
     echo  java version $jver is not supported
     exit
   fi
fi

touch /etc/init.d/ISM_TEST 2>/dev/null
if [[ $? -gt 0 ]]; then
echo Insufficient permissions
exit
fi
rm /etc/init.d/ISM_TEST

silent=""
if [[ "$mode" == "silent" ]]; then
  mode="";
  silent="--silent=y";
fi

tmpDir=/tmp/veracodeism
rm -rf $tmpDir
mkdir $tmpDir
cp ../service/ism-monitor.jar $tmpDir
cd $tmpDir


"$javaExec" -jar ism-monitor.jar --mode=$mode --action=uninstall $silent
