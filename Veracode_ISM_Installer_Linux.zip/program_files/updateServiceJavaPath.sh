#!/bin/bash

if [[ -n "$JAVA_HOME" ]];  then
    echo Using java executable defined in JAVA_HOME $JAVA_HOME

    if [[ -x "$JAVA_HOME/bin/java" ]]; then
        javaExec="$JAVA_HOME/bin/java"
    fi

    if [[ -x "$JAVA_HOME/jre/bin/java" ]]; then
        javaExec="$JAVA_HOME/jre/bin/java"
    fi
fi

if [[ -z "$javaExec" ]]; then
   echo JAVA_HOME not found
   exit
fi

# Replace Java path
sed -i "s|^JAVAEXEC=.*$|JAVAEXEC=$javaExec|" /etc/init.d/Veracode_ISM
service Veracode_ISM stop
service Veracode_ISM start