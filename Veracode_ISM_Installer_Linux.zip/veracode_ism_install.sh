#!/bin/bash
# Copyright (c) 2019 Veracode, Inc.

mode=$1
if [[ -n "$JAVA_HOME" ]];  then
    echo Using java executable defined in JAVA_HOME $JAVA_HOME

    if [[ -x "$JAVA_HOME/bin/java" ]];then
      javaExec="$JAVA_HOME/bin/java"
    fi

    if [[ -x "$JAVA_HOME/jre/bin/java" ]]; then
        javaExec="$JAVA_HOME/jre/bin/java"
    fi
fi
if [[ -z "$javaExec" ]]; then
    javaExec=`which java`;
fi
if [[ -z "$javaExec" ]]; then
   echo Java not found
   exit
fi


touch /etc/init.d/ISM_TEST 2>/dev/null
if [[ $? -gt 0 ]]; then
echo Insufficient permissions
exit
fi
rm /etc/init.d/ISM_TEST

silent=""
if [[ "$mode" == "silent" ]]; then
  mode="";
  silent="--silent=y";
fi

"$javaExec" -jar program_files/was-mvsa-smartendpoint-installer.jar --mode=$mode --java=$javaExec $silent

